package com.example.aidsdemo;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.view.View;
import android.view.Menu;
import android.support.design.widget.Snackbar;
import android.support.design.widget.NavigationView;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.aidsdemo.databinding.ActivityMainBinding;


public class MainActivity extends AppCompatActivity {

    private AppBarConfiguration mAppBarConfiguration;
    private ActivityMainBinding binding;
    private TextView upload;
    private ImageView mine;
    private ImageView message;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        //绑定上传x片按钮
        upload = findViewById(R.id.uploadXPic);
        upload.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, uploadXPic.class);
            startActivity(intent);
        });
        //绑定我的按钮
        mine = findViewById(R.id.mine);
        mine.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, mine.class);
            startActivity(intent);
        });
        //绑定消息按钮
        message = findViewById(R.id.message);
        message.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, message.class);
            startActivity(intent);
        });
        AlertDialog alertDialog = new AlertDialog.Builder(this)
                .setMessage("Dear Mx, if you are confirmed to have AIDS and have been treated for a long time in the community. Suppose you had physical discomfort or skin ecchymosis, or splenomegaly recently; in that case, you might enter the results of your last serological test at the community treatment center into this interface, and we will check whether you have a T. marneffei infection. This can be used as a personal health monitoring tool during your long-term treatment. It is worth noting that this predictive model is still in the research stage, has not been validated by NIH, and has not been incorporated into routine clinical treatment steps. All hints derived from this model are only.   All hints derived from this model are only suggestions for medical purposes.")
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                })
                .create();
        alertDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialog) {
                Button positiveButton = alertDialog.getButton(DialogInterface.BUTTON_POSITIVE);

                // 设置按钮颜色（可以替换为您喜欢的颜色）
                positiveButton.setTextColor(Color.parseColor("#1B4668"));
            }
        });
//显示弹窗
//        alertDialog.show();

//        nav_view
        NavigationView v = findViewById(R.id.nav_view);//找到你要设透明背景的layout 的id
//        v.getBackground().setAlpha(100);//0~255透明度值

//        BitmapFactory.Options options = new BitmapFactory.Options();
//        options.inSampleSize = 2; //宽高分别压缩4倍
//        Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.icon1, options);
//        ImageView showIcon = v.getHeaderView(0).findViewById(R.id.iconHeader);
//        showIcon.setImageBitmap(bitmap);

        setSupportActionBar(binding.appBarMain.toolbar);
        binding.appBarMain.fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        DrawerLayout drawer = binding.drawerLayout;
        NavigationView navigationView = binding.navView;
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_home, R.id.nav_gallery, R.id.nav_slideshow)
                .setDrawerLayout(drawer)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }
}