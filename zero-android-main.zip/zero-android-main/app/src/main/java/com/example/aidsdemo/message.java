package com.example.aidsdemo;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class message extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.message);
    }

}
