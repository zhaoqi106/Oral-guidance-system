package com.example.aidsdemo;

import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;

public class uploadXPic extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.upload_x_pic);

        //找到返回键的View并设置点击事件
        View backButton = findViewById(R.id.uploadXPic_back);
        backButton.setOnClickListener(v -> {
            finish();   //关闭当前Activity，回到上一层
        });
    }

}
