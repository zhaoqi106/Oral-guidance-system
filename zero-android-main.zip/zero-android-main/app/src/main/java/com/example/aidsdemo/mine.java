package com.example.aidsdemo;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;

public class mine extends AppCompatActivity {
    private ImageView home;
    private ImageView message;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mine);
        //绑定首页跳转
        home = findViewById(R.id.mine_home);
        home.setOnClickListener(v -> {
            Intent intent = new Intent(mine.this, MainActivity.class);
            startActivity(intent);
        });
        //绑定信息跳转
        message = findViewById(R.id.mine_message);
        message.setOnClickListener(v -> {
            Intent intent = new Intent(mine.this, message.class);
            startActivity(intent);
        });
    }
}
